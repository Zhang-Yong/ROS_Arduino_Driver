/// DEBUG
// Enable or disable serial debugging of motor speed (comment next line to disable)
//#define DEBUG_MOTORS

/// OUTPUT -- Add Direction_pin for L298N, Athlon, Nov30
/// INA -> 4, INB -> 5, INC->6, IND->7
#define DIRECTION_PIN_INA  4
#define DIRECTION_PIN_INB  5
#define DIRECTION_PIN_INC  6
#define DIRECTION_PIN_IND  7
#define PWM_PIN_A  3
#define PWM_PIN_B  11

/// ADJUST BRAKING AND FADING SPEED
#define SLOWCHANGEDELAY 10                        // higher number: slower fading: 1=no fading
#define BRAKESPEED 3                              // smaller number less abrupt braking (braking reuses FADESPEED)
