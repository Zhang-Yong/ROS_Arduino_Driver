/// DEBUG
// Enable or disable serial debugging of motor speed (comment next line to disable)
//#define DEBUG_MOTORS

/// Athlon-- OUTPUT -- Add Direction_pin for L298N,  Nov30
/// INA -> 4, INB -> 5, INC->6, IND->7
/// UNO interput pin 2 --> left encoder D0, UNO interput pin 3 --> Right enconder D0
/// PWM A change from 3 to pin 10 
#define DIRECTION_PIN_INA  4
#define DIRECTION_PIN_INB  5
#define DIRECTION_PIN_INC  6
#define DIRECTION_PIN_IND  7
#define PWM_PIN_A  10
#define PWM_PIN_B  11
#define PinA_left 2  // 中断0
#define PinB_left 3  // 中断1

/// ADJUST BRAKING AND FADING SPEED
#define SLOWCHANGEDELAY 10                        // higher number: slower fading: 1=no fading
#define BRAKESPEED 3                              // smaller number less abrupt braking (braking reuses FADESPEED)
