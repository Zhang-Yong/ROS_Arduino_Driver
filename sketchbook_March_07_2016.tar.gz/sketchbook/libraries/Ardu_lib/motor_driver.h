/***************************************************************
   Motor driver function definitions - by James Nugen
   *************************************************************/
// Athlon, keep it same, Update ardumoto.cpp file instead to avoid modify moto_driver.ino etc

void initMotorController();
void setMotorSpeed(int i, int spd);
void setMotorSpeeds(int leftSpeed, int rightSpeed);
