// Ardumoto.h - Arduino library to control DC motos using the Ardumoto Shield
// Copyright 2012 Jeroen Doggen (jeroendoggen@gmail.com)
// Athlon -- modify to fit L298N moto controller

#ifndef Ardumotor_h
#define Ardumotor_h

#include "defines.h"

class Ardumoto
{
  public:
    Ardumoto();                                   // Constructor
    ~Ardumoto();                                  // Destructor

    void begin();
    // Athlon -- modify begin MotoA/B to fit 2 direction pins for L298N 
//    void beginMotoA(int directionPin, int pwmPin);
//    void beginMotoB(int directionPin, int pwmPin);
    
    void beginMotoA(int directionPinA,int directionPinB, int pwmPin);
    void beginMotoB(int directionPinA,int directionPinB, int pwmPin);

  //Athlon, change to int type  
//    void setSpeed(char moto, int speed);          // Set the speed of a selected motor, range: -100 to +100
    void setSpeed(int moto, int speed);   
//    void setM1Speed(int speed);                    // set M1 speed, compatible with main program -Athlon
//    void setM2Speed(int speed); 	           // set M2 speed, -- Athlon

    void slowChange(char moto, int speed);        // Fade the speed of a motor slowly to a specific value: range -100 to 100

    void stop(char moto);
    void brake(char moto);                        // Brake the motor
    void brakeAgressive(char moto);               // Brake the motor

  private:
    int _motoSpeedA;
    int _motoSpeedB;
};
#endif
