#ifndef _ROS_turtlebot_app_manager_AppInstallationState_h
#define _ROS_turtlebot_app_manager_AppInstallationState_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "turtlebot_app_manager/ExchangeApp.h"

namespace turtlebot_app_manager
{

  class AppInstallationState : public ros::Msg
  {
    public:
      uint8_t installed_apps_length;
      turtlebot_app_manager::ExchangeApp st_installed_apps;
      turtlebot_app_manager::ExchangeApp * installed_apps;
      uint8_t available_apps_length;
      turtlebot_app_manager::ExchangeApp st_available_apps;
      turtlebot_app_manager::ExchangeApp * available_apps;

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      *(outbuffer + offset++) = installed_apps_length;
      *(outbuffer + offset++) = 0;
      *(outbuffer + offset++) = 0;
      *(outbuffer + offset++) = 0;
      for( uint8_t i = 0; i < installed_apps_length; i++){
      offset += this->installed_apps[i].serialize(outbuffer + offset);
      }
      *(outbuffer + offset++) = available_apps_length;
      *(outbuffer + offset++) = 0;
      *(outbuffer + offset++) = 0;
      *(outbuffer + offset++) = 0;
      for( uint8_t i = 0; i < available_apps_length; i++){
      offset += this->available_apps[i].serialize(outbuffer + offset);
      }
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      uint8_t installed_apps_lengthT = *(inbuffer + offset++);
      if(installed_apps_lengthT > installed_apps_length)
        this->installed_apps = (turtlebot_app_manager::ExchangeApp*)realloc(this->installed_apps, installed_apps_lengthT * sizeof(turtlebot_app_manager::ExchangeApp));
      offset += 3;
      installed_apps_length = installed_apps_lengthT;
      for( uint8_t i = 0; i < installed_apps_length; i++){
      offset += this->st_installed_apps.deserialize(inbuffer + offset);
        memcpy( &(this->installed_apps[i]), &(this->st_installed_apps), sizeof(turtlebot_app_manager::ExchangeApp));
      }
      uint8_t available_apps_lengthT = *(inbuffer + offset++);
      if(available_apps_lengthT > available_apps_length)
        this->available_apps = (turtlebot_app_manager::ExchangeApp*)realloc(this->available_apps, available_apps_lengthT * sizeof(turtlebot_app_manager::ExchangeApp));
      offset += 3;
      available_apps_length = available_apps_lengthT;
      for( uint8_t i = 0; i < available_apps_length; i++){
      offset += this->st_available_apps.deserialize(inbuffer + offset);
        memcpy( &(this->available_apps[i]), &(this->st_available_apps), sizeof(turtlebot_app_manager::ExchangeApp));
      }
     return offset;
    }

    const char * getType(){ return "turtlebot_app_manager/AppInstallationState"; };
    const char * getMD5(){ return "46d45bbda08250199267aff8c0ee8c41"; };

  };

}
#endif