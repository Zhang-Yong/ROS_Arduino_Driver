#ifndef _ROS_kobuki_msgs_WheelDropEvent_h
#define _ROS_kobuki_msgs_WheelDropEvent_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace kobuki_msgs
{

  class WheelDropEvent : public ros::Msg
  {
    public:
      uint8_t state;
      uint8_t wheel;
      enum { RAISED =  0 };
      enum { DROPPED =  1 };
      enum { LEFT =  0 };
      enum { RIGHT =  1 };

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      *(outbuffer + offset + 0) = (this->state >> (8 * 0)) & 0xFF;
      offset += sizeof(this->state);
      *(outbuffer + offset + 0) = (this->wheel >> (8 * 0)) & 0xFF;
      offset += sizeof(this->wheel);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      this->state =  ((uint8_t) (*(inbuffer + offset)));
      offset += sizeof(this->state);
      this->wheel =  ((uint8_t) (*(inbuffer + offset)));
      offset += sizeof(this->wheel);
     return offset;
    }

    const char * getType(){ return "kobuki_msgs/WheelDropEvent"; };
    const char * getMD5(){ return "3de70ca325cbb0383c52cf4e5306a686"; };

  };

}
#endif