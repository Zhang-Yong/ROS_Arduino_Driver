#ifndef _ROS_SERVICE_SetDigitalOutputs_h
#define _ROS_SERVICE_SetDigitalOutputs_h
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace create_node
{

static const char SETDIGITALOUTPUTS[] = "create_node/SetDigitalOutputs";

  class SetDigitalOutputsRequest : public ros::Msg
  {
    public:
      uint8_t digital_out_0;
      uint8_t digital_out_1;
      uint8_t digital_out_2;

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      *(outbuffer + offset + 0) = (this->digital_out_0 >> (8 * 0)) & 0xFF;
      offset += sizeof(this->digital_out_0);
      *(outbuffer + offset + 0) = (this->digital_out_1 >> (8 * 0)) & 0xFF;
      offset += sizeof(this->digital_out_1);
      *(outbuffer + offset + 0) = (this->digital_out_2 >> (8 * 0)) & 0xFF;
      offset += sizeof(this->digital_out_2);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      this->digital_out_0 =  ((uint8_t) (*(inbuffer + offset)));
      offset += sizeof(this->digital_out_0);
      this->digital_out_1 =  ((uint8_t) (*(inbuffer + offset)));
      offset += sizeof(this->digital_out_1);
      this->digital_out_2 =  ((uint8_t) (*(inbuffer + offset)));
      offset += sizeof(this->digital_out_2);
     return offset;
    }

    const char * getType(){ return SETDIGITALOUTPUTS; };
    const char * getMD5(){ return "95ef1ce60d04abfe27bea339a6261f29"; };

  };

  class SetDigitalOutputsResponse : public ros::Msg
  {
    public:
      bool done;

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      union {
        bool real;
        uint8_t base;
      } u_done;
      u_done.real = this->done;
      *(outbuffer + offset + 0) = (u_done.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->done);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      union {
        bool real;
        uint8_t base;
      } u_done;
      u_done.base = 0;
      u_done.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->done = u_done.real;
      offset += sizeof(this->done);
     return offset;
    }

    const char * getType(){ return SETDIGITALOUTPUTS; };
    const char * getMD5(){ return "89bb254424e4cffedbf494e7b0ddbfea"; };

  };

  class SetDigitalOutputs {
    public:
    typedef SetDigitalOutputsRequest Request;
    typedef SetDigitalOutputsResponse Response;
  };

}
#endif
